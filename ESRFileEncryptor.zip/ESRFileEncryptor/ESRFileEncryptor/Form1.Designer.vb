﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RemoveDoubleQuotes = New System.Windows.Forms.Button()
        Me.Encrypt = New System.Windows.Forms.Button()
        Me.Decrypt = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SuspendLayout()
        '
        'RemoveDoubleQuotes
        '
        Me.RemoveDoubleQuotes.Location = New System.Drawing.Point(96, 12)
        Me.RemoveDoubleQuotes.Name = "RemoveDoubleQuotes"
        Me.RemoveDoubleQuotes.Size = New System.Drawing.Size(202, 51)
        Me.RemoveDoubleQuotes.TabIndex = 0
        Me.RemoveDoubleQuotes.Text = "Remove Double Quotes"
        Me.RemoveDoubleQuotes.UseVisualStyleBackColor = True
        Me.RemoveDoubleQuotes.Visible = False
        '
        'Encrypt
        '
        Me.Encrypt.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Encrypt.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Encrypt.Location = New System.Drawing.Point(109, 121)
        Me.Encrypt.Name = "Encrypt"
        Me.Encrypt.Size = New System.Drawing.Size(180, 76)
        Me.Encrypt.TabIndex = 1
        Me.Encrypt.Text = "Encrypt"
        Me.Encrypt.UseVisualStyleBackColor = True
        '
        'Decrypt
        '
        Me.Decrypt.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Decrypt.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Decrypt.Location = New System.Drawing.Point(109, 242)
        Me.Decrypt.Name = "Decrypt"
        Me.Decrypt.Size = New System.Drawing.Size(180, 74)
        Me.Decrypt.TabIndex = 2
        Me.Decrypt.Text = "Decrypt"
        Me.Decrypt.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(411, 410)
        Me.Controls.Add(Me.Decrypt)
        Me.Controls.Add(Me.Encrypt)
        Me.Controls.Add(Me.RemoveDoubleQuotes)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents RemoveDoubleQuotes As System.Windows.Forms.Button
    Friend WithEvents Encrypt As System.Windows.Forms.Button
    Friend WithEvents Decrypt As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog

End Class
